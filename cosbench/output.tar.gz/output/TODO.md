TODO
----
COSBench is an ongoing project, in next six months, we plan to make below improvements:

1. more storage interface support, list is TBD.

2. authentication caching

3. LIST operation

4. workload packages shipped


If you have any other suggestions or you want to work with us together. please contact us at yaguang.wang@intel.com.


== END ==